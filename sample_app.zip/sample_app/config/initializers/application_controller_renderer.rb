# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'e02f699bcb5cdd280463ce50d506369fab1f93ea0903455302ca8d7b86254d74c8772f536b9296eb0331e7f48e7e9dc74e89fd4f6dcb09ef365bdfbcdcbc2fd1'
